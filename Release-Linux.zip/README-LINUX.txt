Warning: Extremely in-progress
Only tested on Ubuntu 20.04 virtual machine and liveusb
Requires (apt-get install):
  libfreetype6
  libopenal1
  libgdiplus
  
Run through terminal by ./ShanghaiEXE
